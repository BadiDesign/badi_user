from django.apps import AppConfig


class BadiUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'badi_user'
    verbose_name = 'Users'
