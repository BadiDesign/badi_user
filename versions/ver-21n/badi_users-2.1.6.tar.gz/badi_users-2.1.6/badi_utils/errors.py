class BadiErrorCodes:
    phone = 'INVALID_PHONE'
    unique = 'EARLY_EXISTS'
    sms_send_recently = 'SMS_SEND_RECENTLY'
    not_found = 'NOT_FOUND'
    expired = 'EXPIRED'
    wrong_code = 'WRONG_CODE'
    permission_denied = "NO_PERMISSION"
    weak_password = "WEAK_PASSWORD"
