from django.contrib import admin
from badi_ticket.models import Message, Ticket

admin.site.register(Message)
admin.site.register(Ticket)
