from django.apps import AppConfig


class TicketConfig(AppConfig):
    name = 'badi_ticket'
